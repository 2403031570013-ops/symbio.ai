from motor.motor_asyncio import AsyncClient, AsyncDatabase
from beanie import init_beanie
from app.core.config import settings

client: AsyncClient | None = None
database: AsyncDatabase | None = None


async def connect_to_mongo():
    """Connect to MongoDB using Motor and initialize Beanie."""
    global client, database
    client = AsyncClient(settings.MONGODB_URI)
    database = client[settings.DATABASE_NAME]
    
    # Import all models for Beanie to register them
    from app.models.user import User
    from app.models.auth import RefreshToken, EmailOtp, MobileOtp
    
    await init_beanie(database=database, models=[User, RefreshToken, EmailOtp, MobileOtp])


async def close_mongo():
    """Close MongoDB connection."""
    global client
    if client:
        client.close()


def get_database() -> AsyncDatabase:
    """Get the async database instance."""
    return database


